﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static double[] valor;

        static void inverteTela()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }
        static void lancar()
        {
            int motor;
            do
            {
                Console.Write("Qual o motor ?");
                motor = int.Parse(Console.ReadLine());
            }
            while (motor < 1 || motor > 15);

            Console.Write("Qual o valor ?");
            valor[motor - 1] += double.Parse(Console.ReadLine());

            Console.WriteLine("Valor registrado!");

        }
        static void mostrar()
        {
            int motor;
            double total;

            total = 0;
            for (motor = 0; motor < 15; motor++)
            {
                Console.WriteLine("Motor {0}: R$ {1}",
                    motor + 1, valor[motor]);
                total += valor[motor];
            }
            Console.WriteLine("-------");
            Console.WriteLine("Total: R$ {0}", total);

        }
        static void Main(string[] args)
        {
            
            valor = new double[15];
            int op;
            
            inverteTela();

            do
            {
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Lançar valor");
                Console.WriteLine("2. Mostrar valores");
                Console.Write("Sua opção: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        {
                            lancar();
                            break;
                        }
                    case 2:
                        {
                            mostrar();
                            break;
                        }
                }
            }
            while (op != 0);
            mostrar();
        }
    }
}
