﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {

        static void inverteTela()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }

        static int somar(int a1, int a2)
        {
            int r;
            r = a1 + a2;
            return r;
        }
        static void Main(string[] args)
        {
            int n1;
            int n2;

            inverteTela();
            Console.Write("Digite o 1º número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Digite o 2º número: ");
            n2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Resultado: {0}", somar(n1, n2));
        }
    }
}
